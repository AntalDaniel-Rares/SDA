#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "bfs.h"


typedef struct g{
    int V;
    int E;        
    int **a;
}Graph;

Graph *graphcreate(Graph *g)
{
    g = (Graph*) malloc (sizeof(Graph));
    g->E = 0;
    g->V = 0;

    g->a = (int**) malloc(600*sizeof(int*));

    for(int i = 0; i < 600; i++)
        g->a[i] = (int*) malloc(600*sizeof(int));

    return g;
}

int search(char *station, char **list, int k, int *i)
{
    *i = 0;
    int ok = 0;

    while(*i < k)
        {
            if(strcmp(station, list[*i]) == 0)
            {
                ok = 1;
                break;
            }
                    
            (*i)++;
        }

    return ok;

}

void busy2(Graph *g, int k, char **list)
{

    int max1 = 0, max2 = 0, poz1, poz2, *visits;

    visits = (int*) calloc(k,sizeof(int));

    for(int i = 0; i < k; i++)
        for(int j = 0; j < k; j++)
            if(g->a[i][j] == 1)
                visits[i]++;

    for(int i = 0; i < k; i++)
        if(visits[i] > max1)
            {
                max1 = visits[i];
                poz1 = i;
            }
        else if(visits[i] > max2)
            {
                max2 = visits[i];
                poz2 = i;
            }

    FILE *f;

    f = fopen("primul.txt","wt");

    fprintf(f, "%s(statia %d) - %d vizite(folosind graful pot afla doar prima cea mai vizitata satie de trenuri venind din statii diferite si unice)", list[poz1], poz1, visits[poz1]);

    fclose(f);

    f = fopen("doilea.txt","wt");

    fprintf(f, "%s(statia %d) - %d vizite(aceeasi problema ca la prima statie)", list[poz2], poz2, visits[poz2]);

    fclose(f);
}

void DFS(Graph *g, int *visited, int i, char **list, FILE *f)
{
    int j;

	fprintf(f, "Visited %s\n", list[i]);
    visited[i] = 1;
	
	for(j = 0; j < g->V; j++)
       if(!visited[j] && g->a[i][j] == 1)
            DFS(g, visited, j, list, f);

}

int main()
{
    char **list, *filename, *station;

    FILE* f;
    Graph *g, *go;

    g = graphcreate(g);
    go = graphcreate(go);

    int k = 0;

    f = fopen("_all_files.txt","rt");
    filename = (char*) malloc (10*sizeof(char));
    station = (char*) malloc (20*sizeof(char));
    list = (char**) malloc (600*sizeof(char*));

    while(fscanf(f, "%s", filename) != EOF)
    {
        int first = 1, poz, i;

        FILE* F;
        if(fopen(filename,"rt") != NULL)
            F = fopen(filename,"rt");
        else continue;

        while(fscanf(F, "%[^\n] ", station) != EOF)
            {
                station[strlen(station) - 1] = '\0';
                if(!search(station, list, k, &i))
                    list[k++] = strdup(station);

                if(!first) 
                {
                    g->a[poz][i] = 1;
                    g->a[i][poz] = 1;
                    go->a[poz][i] = 1;
                }

                poz = i;
                first = 0;
            }
        
        fclose(F);
            
    }

    int i = 0;

    while(i < k)
    {
        //printf("%s\n", list[i]);
        i++;
    }

    fclose(f);

    int j = 0, nr = 0;
    for(i = 0; i < k; i++)
        {
            for(j = 0; j < k; j++)
                {
                    if(g->a[i][j] != 0)
                        g->E++;
                    if(go->a[i][j] != 0)
                        go->E++;
                }

        }
    
    FILE *m, *n;

    m = fopen("muchii.txt", "wt");
    n = fopen("noduri.txt", "wt");

    g->V = k;
    fprintf(n, "numar varfuri: %d", g->V);
    fprintf(m, "numar muchii: %d", g->E/2);
    fprintf(m, "\nnumar muchii graf orientat: %d", go->E);

    fclose(m);
    fclose(n);

    m = fopen("orasul_meu.txt", "wt");

    station = strdup("Bacau\0");
    if(search(station, list, k, &i))
        fprintf(m, "Statia %s: %d", station, i);
    else fprintf(m, "Statia %s nu exista.", station);

    fclose(m);

    busy2(g,k,list);// cele mai vizitate statii
    
    //bfs(g, 0, list);

    int *visited;

    visited = (int *) calloc(g->V, sizeof(int));

    f = fopen("parcurgere_dfs", "wt");

    DFS(g, visited, 0, list, f);

    free(visited);
    fclose(f);

    return 0;
}